import React, { useRef, useLayoutEffect } from 'react';
import { motion } from 'motion/react';
import { TooltipContent } from '../types.ts';
import { getChapterIcon } from '../utils.ts';
import { MUQATTAT_DEFINITIONS } from '../data/muqattatDefinitions.ts';

interface TooltipProps {
  visible: boolean;
  content: TooltipContent | null;
  position: { x: number; y: number };
}

const Tooltip: React.FC<TooltipProps> = ({ visible, content, position }) => {
  const tooltipRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const tooltipNode = tooltipRef.current;
    if (!tooltipNode) return;

    if (visible && content) {
      // We need the tooltip's dimensions to position it correctly.
      const { offsetWidth, offsetHeight } = tooltipNode;
      const { innerWidth, innerHeight } = window;
      const margin = 16; // A small gap from the cursor and viewport edges

      // Calculate position, defaulting to bottom-right of the cursor
      let newX = position.x + margin;
      let newY = position.y + margin;

      // Adjust if it overflows the viewport
      if (newX + offsetWidth > innerWidth - margin) {
        newX = position.x - offsetWidth - margin;
      }
      if (newY + offsetHeight > innerHeight - margin) {
        newY = position.y - offsetHeight - margin;
      }

      // Clamp to ensure it never goes off-screen
      newX = Math.max(margin, newX);
      newY = Math.max(margin, newY);
      
      // Apply position directly to the DOM for performance.
      // Using transform is smoother than animating top/left.
      tooltipNode.style.transform = `translate(${newX}px, ${newY}px)`;
      // Fade the tooltip in
      tooltipNode.style.opacity = '1';
    } else {
      // Fade the tooltip out
      tooltipNode.style.opacity = '0';
    }
  }, [visible, position, content]);

  // Don't render anything if there's no content to display.
  // This allows the component to be mounted for the fade-out transition.
  if (!content) return null;

  // Base styles: fixed position, transparent, with a transition.
  // The useLayoutEffect will handle positioning and fading in/out.
  const baseStyle: React.CSSProperties = {
    position: 'fixed',
    top: 0,
    left: 0,
    pointerEvents: 'none',
    zIndex: 1000,
    opacity: 0, // Start transparent, effect will fade it in.
    transition: 'opacity 0.2s ease-in-out',
  };

  const renderContent = () => {
    if (content.type === 'chapter') {
        const { chapterDetails, verseCount, muqattat, color } = content;
        const iconSrc = getChapterIcon(chapterDetails.revelationType);
        return (
            <div className="flex flex-col gap-2">
                <div className="flex items-center gap-3">
                    <img src={iconSrc} alt={chapterDetails.revelationType} className="w-9 h-9 flex-shrink-0" title={chapterDetails.revelationType}/>
                    <div className="min-w-0">
                        <h3 className="font-bold text-lg" style={{ color: color, textShadow: `0 0 5px ${color}` }}>
                            {chapterDetails.number}. {chapterDetails.englishName}
                        </h3>
                        <p className="text-base italic text-gray-400">{chapterDetails.transliteration}</p>
                    </div>
                </div>
                {chapterDetails.scienceTooltip && (
                    <div className="bg-cyan-950/20 border-l-2 border-cyan-500 py-1.5 px-3 -mx-1 my-1">
                         <p className="text-[11px] font-black uppercase tracking-widest text-cyan-400 mb-0.5">Science Context</p>
                         <p className="text-xs text-gray-200 font-medium leading-relaxed">{chapterDetails.scienceTooltip}</p>
                    </div>
                )}
                <div className="grid grid-cols-2 gap-y-1 gap-x-4 text-sm border-t border-gray-700 pt-2 text-gray-300">
                    <div><strong className="text-gray-400 font-medium">Verses:</strong> {verseCount}</div>
                    <div><strong className="text-gray-400 font-medium">Juz':</strong> {chapterDetails.juz}</div>
                </div>
                {muqattat && (
                    <div className="border-t border-gray-700 pt-2 text-gray-300">
                        <strong className="text-gray-400 font-medium">Muqatta'at:</strong> 
                        <span dir="rtl" className="font-mono text-lg ml-2 muqattat-glow">
                            {muqattat.join(' ')}
                        </span>
                        <div className="mt-2 space-y-2">
                            {muqattat.flatMap(m => m.split('')).map(char => {
                                const def = MUQATTAT_DEFINITIONS[char];
                                return def ? (
                                    <div key={char} className="text-[11px] bg-slate-900/80 p-2 rounded border border-cyan-500/20">
                                        <span className="font-bold text-cyan-400">{char}:</span> {def.name} <span className="text-gray-500">[{def.field}]</span><br/>
                                        <span className="text-gray-300">{def.function}</span>
                                    </div>
                                ) : null;
                            })}
                        </div>
                    </div>
                )}
            </div>
        )
    }

    if (content.type === 'functional') {
        const { message, chapterName, lastVerseText, color } = content;
        return (
            <div className="flex flex-col gap-1 min-w-[280px]">
                <div className="flex items-baseline justify-between gap-4">
                    <span className="font-bold text-[13px] tracking-wide" style={{ color, textShadow: `0 0 4px ${color}` }}>{message}</span>
                    <span className="text-[10px] opacity-40 text-gray-500 uppercase font-mono">{chapterName}</span>
                </div>
                <div className="w-full h-px bg-gray-700/30 my-1" />
                <div className="relative overflow-hidden w-full h-5">
                    <motion.div
                        className="whitespace-nowrap inline-flex"
                        animate={{ x: ["0%", "-50%"] }}
                        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                    >
                        <span className="text-gray-400 italic text-[11px] leading-relaxed pr-12">
                            {lastVerseText}
                        </span>
                        <span className="text-gray-400 italic text-[11px] leading-relaxed pr-12">
                            {lastVerseText}
                        </span>
                    </motion.div>
                </div>
            </div>
        );
    }

    if (content.type === 'moondial') {
        const { hourStr, chapters, title, role, keyVerse, breath, breathDesc, influence, color } = content;
        return (
            <div className="flex flex-col gap-2 min-w-[300px]">
                <div className="flex items-center justify-between border-b border-gray-700/65 pb-2 mb-1">
                    <span className="text-lg font-black uppercase tracking-wider text-white" style={{ textShadow: `0 0 8px ${color}` }}>
                        {hourStr} Dial
                    </span>
                    <span className="text-[10px] font-mono text-gray-200 px-2.5 py-0.5 rounded-full bg-slate-950/70 border border-white/5" style={{ color }}>
                        {breath} chapters
                    </span>
                </div>
                <div>
                    <h3 className="font-bold text-xs tracking-wide text-gray-200 uppercase">
                        {title}
                    </h3>
                    <p className="text-[11px] text-gray-400">{influence}</p>
                </div>
                <div className="bg-slate-950/50 border border-white/5 rounded-xl py-2.5 px-3.5 my-1 space-y-1.5 shadow-inner">
                    <div className="text-[9px] font-black uppercase tracking-[0.15em] text-cyan-400">Memory Recovery Protocol</div>
                    <div className="text-xs text-gray-200 leading-relaxed font-light">{role}</div>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[10px] bg-slate-950/20 py-1.5 px-2.5 rounded-lg border border-white/5">
                    <div>
                        <span className="text-gray-400 font-medium block text-[9px] uppercase">Chapters:</span>
                        <span className="text-gray-200 font-mono font-bold">{chapters}</span>
                    </div>
                    <div>
                        <span className="text-gray-400 font-medium block text-[9px] uppercase">Key Verses:</span>
                        <span className="text-gray-200 font-mono font-bold text-cyan-400">{keyVerse}</span>
                    </div>
                </div>
                <div className="border-t border-gray-700/60 pt-2 mt-1 flex justify-between items-center text-[10px]">
                    <span className="uppercase font-mono text-gray-500 text-[8px] tracking-widest">Torque torque breath</span>
                    <span className="font-semibold text-gray-300" style={{ color }}>{breathDesc}</span>
                </div>
            </div>
        );
    }

    // 'verse' type
    const directLink = `https://reader.wikisubmission.org/quran/${content.surah}:${content.verse}`;
    return (
        <>
            <div>
                <a href={directLink} target="_blank" rel="noopener noreferrer" style={{ color: content.color, textShadow: `0 0 5px ${content.color}` }} className="font-bold hover:underline">
                    Verse [{content.surah}:{content.verse}]
                </a>
            </div>
            <div className="mt-3 pt-3 border-t border-gray-700">
                <h4 className="font-semibold text-gray-400 mb-1" style={{ color: content.color, opacity: 0.8 }}>Translation</h4>
                <p className="text-gray-200 pl-2 border-l-2" style={{borderColor: content.color}}>
                {content.englishText}
                </p>
            </div>
            {content.banglaText && (
                <div className="mt-3 pt-3 border-t border-gray-700">
                    <h4 className="font-semibold text-cyan-400/90 mb-1">Secondary</h4>
                    <p className="text-gray-200 pl-2 border-l-2 border-cyan-400/50">
                    {content.banglaText}
                    </p>
                </div>
            )}
        </>
    )
  }

  return (
    <div ref={tooltipRef} style={baseStyle} className="bg-gray-900 border border-gray-600 rounded-md shadow-2xl p-4 max-w-sm lg:max-w-md text-sm" role="tooltip" aria-hidden={!visible}>
      {renderContent()}
    </div>
  );
};

export default Tooltip;
